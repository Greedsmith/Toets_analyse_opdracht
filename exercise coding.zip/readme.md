create conda environment at least with:
- python=3.12
- matplotlib
- pandas
- tabulate
- openpyxl
